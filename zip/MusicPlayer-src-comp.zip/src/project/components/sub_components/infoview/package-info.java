/**
 * @author Jack Meng
 * 
 *         <p>
 *         This sub-package incoporates all of the packages needed for the InfoView class
 *         </p>
 * 
 * @see project.components.InfoView
 */
package project.components.sub_components.infoview;
