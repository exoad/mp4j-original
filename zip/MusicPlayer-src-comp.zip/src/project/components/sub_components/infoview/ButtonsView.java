package project.components.sub_components.infoview;

import javax.swing.JPanel;

public class ButtonsView extends JPanel {
  public ButtonsView() {

  }
}
