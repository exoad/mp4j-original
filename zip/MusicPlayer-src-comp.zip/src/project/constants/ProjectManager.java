package project.constants;

public class ProjectManager {
  private ProjectManager() {}

  public static final boolean DEBUG_LAYOUT = false;
}
