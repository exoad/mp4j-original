/**
 * @author exoad
 * 
 * This is a simple Open Source Music Player made using Java.
 * 
 * If you would like the use only the audio player library,
 * you use the {@link project.audio.*} package.
 * 
 * @see project.audio
 * @since 2.0
 * @version 2.0
 */

package project;
