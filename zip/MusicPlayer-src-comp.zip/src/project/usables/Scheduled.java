package project.usables;

public interface Scheduled {
  void run();
}
