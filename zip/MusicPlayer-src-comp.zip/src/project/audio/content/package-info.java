/**
 * @author exoad
 * <p>
 * This package contains all audio library wrappers which details things
 * like Audio File types and others.
 * It also implements and extends other external audio libraries for much more
 * benefitted audio parsing and playing
 * </p>
 * @since 2.0
 * @version 2.0
 */
package project.audio.content;
