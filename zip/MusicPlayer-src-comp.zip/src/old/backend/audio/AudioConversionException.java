package backend.audio;

public class AudioConversionException extends Exception {
  public AudioConversionException(String message) {
    super(message);
  }
  
}
