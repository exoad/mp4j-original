package backend.audio;

public class GlobalVars {
  private GlobalVars() {

  }

  public static final String ITEM_DIR = "MP4J/cache/audio";
  public static final String CODEC_FINAL = "MP4J/cache/codec";
}
