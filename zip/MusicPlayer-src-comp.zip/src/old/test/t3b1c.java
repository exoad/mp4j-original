package test;

public class t3b1c extends test.MediaPlacer {
  
}
