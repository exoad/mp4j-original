package app.interfaces.modifier;

import java.awt.*;

public class WindowPaneSize {
  public static final Dimension FINALSIZE = new Dimension(500, 200);
}
