package app.java;

public class HardLock {
    public static boolean CLI = false;
}
