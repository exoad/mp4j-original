package app.interfaces.theme;

import javax.swing.*;
import java.awt.*;

public interface Refresh {
  public void refresh(Window jfts) throws UnsupportedLookAndFeelException;
  public Color getBorderColor();
}